Name: Krishna Surapaneni
Section: 18064
UFL email: k.surapaneni@ufl.edu
System: Windows
Compiler: g++
SFML version: 2.5.1
IDE: CLion
Other notes: None